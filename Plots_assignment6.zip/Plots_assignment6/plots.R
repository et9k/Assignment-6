library(ggplot2)
library(readxl)
seq1<- read_excel("seq1.xlsx")
rc_seq1 <- read_excel("seq2.xlsx")
seq2<- read_excel("seq3.xlsx")
rc_seq2 <- read_excel("seq4.xlsx")
seq3<- read_excel("seq5.xlsx")
rc_seq3 <- read_excel("seq6.xlsx")
seq4<- read_excel("seq7.xlsx")
rc_seq4 <- read_excel("seq8.xlsx")
seq5<- read_excel("seq9.xlsx")
rc_seq5 <- read_excel("seq10.xlsx")
seq6<- read_excel("seq11.xlsx")
rc_seq6 <- read_excel("seq12.xlsx")
seq7<- read_excel("seq13.xlsx")
rc_seq7 <- read_excel("seq14.xlsx")
seq8<- read_excel("seq15.xlsx")
rc_seq8 <- read_excel("seq16.xlsx")
seq9<- read_excel("seq17.xlsx")
rc_seq9 <- read_excel("seq18.xlsx")
seq10<- read_excel("seq19.xlsx")
rc_seq10 <- read_excel("seq20.xlsx")
seq11<- read_excel("seq21.xlsx")
rc_seq11 <- read_excel("seq22.xlsx")

p1 <- ggplot(seq1,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq1, stat="identity", alpha = 0.1, color="red")
print(p1+ labs(y="Motif Matching Score", x="Sequence", title="Seq1"))

p2 <- ggplot(seq2,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq2, stat="identity", alpha = 0.1, color="red")
print(p2+ labs(y="Motif Matching Score", x="Sequence", title="Seq2"))

p3 <- ggplot(seq3,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq3, stat="identity", alpha = 0.1, color="red")
print(p3+ labs(y="Motif Matching Score", x="Sequence", title="Seq3"))

p4 <- ggplot(seq4,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq4, stat="identity", alpha = 0.1, color="red")
print(p4+ labs(y="Motif Matching Score", x="Sequence", title="Seq4"))

p5 <- ggplot(seq5,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq5, stat="identity", alpha = 0.1, color="red")
print(p5+ labs(y="Motif Matching Score", x="Sequence", title="Seq5"))

p6 <- ggplot(seq6,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq6, stat="identity", alpha = 0.1, color="red")
print(p6+ labs(y="Motif Matching Score", x="Sequence", title="Seq6"))

p7 <- ggplot(seq7,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq7, stat="identity", alpha = 0.1, color="red")
print(p7+ labs(y="Motif Matching Score", x="Sequence", title="Seq7"))

p8 <- ggplot(seq8,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq8, stat="identity", alpha = 0.1, color="red")
print(p8+ labs(y="Motif Matching Score", x="Sequence", title="Seq8"))

p9 <- ggplot(seq9,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq9, stat="identity", alpha = 0.1, color="red")
print(p9+ labs(y="Motif Matching Score", x="Sequence", title="Seq9"))

p10 <- ggplot(seq10,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq10, stat="identity", alpha = 0.1, color="red")
print(p10+ labs(y="Motif Matching Score", x="Sequence", title="Seq10"))

p11 <- ggplot(seq11,aes(sequence,score))+
  geom_bar(alpha=0.1,stat="identity", color = "blue")+
  geom_bar(data = rc_seq11, stat="identity", alpha = 0.1, color="red")
print(p11+ labs(y="Motif Matching Score", x="Sequence", title="Seq11"))






